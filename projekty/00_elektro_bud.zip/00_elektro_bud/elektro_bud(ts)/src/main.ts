/*
Elektro-Bud to program do obslugi magazynu.
Można w nim:
-dodać nowy produkt
-usunać produkt
-zobaczyc produkty
-zapisać produkty zeby nie zniknęły po zamknięciu strony
-wyszukać produkt po nazwie lub kodzie ean
*/
type Produkt = {
    ean: string;// w tym przypadku lepiej uzyc string a nie number poniewaz nie wykonujemy na nim obliczen 
    nazwa: string;
    kategoria: string;
    sektor: string;
    regal: string;
    polka: string;
    ilosc: number;
};

let produkty: Produkt[] = [
 { ean: "9876543219", nazwa: "Kabel", kategoria: "Kable", sektor: "K", regal: "7", polka: "24", ilosc: 29 },
 { ean: "1234567891", nazwa: "Żarowka", kategoria: "Oświetlenie", sektor: "O", regal: "9", polka: "12", ilosc: 54 },
 { ean: "5748383874", nazwa: "Led", kategoria: "Oświetlenie", sektor: "O", regal: "10", polka: "11", ilosc: 25 }
];

const formularz = document.getElementById("formularz") as HTMLFormElement; // lapiemy pola ze strony
const ean = document.getElementById("ean") as HTMLInputElement; //html... pole do wpisania
const nazwa = document.getElementById("nazwa") as HTMLInputElement;
const kategoria = document.getElementById("kategoria") as HTMLInputElement; 
const sektor = document.getElementById("sektor") as HTMLInputElement; 
const regal = document.getElementById("regal") as HTMLInputElement; 
const polka = document.getElementById("polka") as HTMLInputElement; 
const ilosc = document.getElementById("ilosc") as HTMLInputElement; 
const szukaj = document.getElementById("szukaj") as HTMLInputElement; 
const lista = document.getElementById("lista") as HTMLTableSectionElement; 

let zapis = localStorage.getItem("produkty"); // Sprawdzamy zapisane produkty

if (zapis != null) { // czy istniwje zapis
    produkty = JSON.parse(zapis) as Produkt[]; // JSON.parse(zapis)- tekst -> dane
}
function zapisz() {// zapisuje produkty w przeglądarce
    localStorage.setItem("produkty", JSON.stringify(produkty)); // zamienism produkty na tekst i zapisuje

}

function pokaz() {
     lista.innerHTML = ""; 
    let tekst = szukaj.value.toLowerCase(); //pbieram tekst ze strony i zamieniam male litery na male

    for (let p of produkty) { // Lecimy po produktach
        if (p.nazwa.toLowerCase().includes(tekst) || p.ean.includes(tekst)) { // czy zawiera wpisany tekst 
            let wiersz = document.createElement("tr"); // nowy wiersz

            wiersz.innerHTML =
                "<td>" + p.ean + "</td>" +
                "<td>" + p.nazwa + "</td>" +
                "<td>" + p.kategoria + "</td>" +
                "<td>" + p.sektor + "</td>" +
                "<td>" + p.regal + "</td>" +
                "<td>" + p.polka + "</td>" +
                "<td>" + p.ilosc + "</td>"; // dane do tabeli

             let komorka = document.createElement("td"); // miejsce na guzik
             let guzik = document.createElement("button");
             guzik.textContent = "Usuń";
             guzik.onclick = function () { usun(p.ean); }; // Klik i produkt znika
             komorka.appendChild(guzik); // wkładamy guzik do komórki
             wiersz.appendChild(komorka); // dodajemy komórke do wiersa
            lista.appendChild(wiersz); // pokazujemy wiersz na stronie
        }
    }
}
formularz.onsubmit = function (event) { //uruchomi kod po zatwierdszeniu formularza
    event.preventDefault(); //blok domyslnego dzialania i odswiezenia strony
    let nowy: Produkt = { 
        ean: ean.value,
        nazwa: nazwa.value,
        kategoria: kategoria.value,
         sektor: sektor.value,
        regal: regal.value,
        polka: polka.value,
        ilosc: Number(ilosc.value)//dane z formularza
    };
    produkty.push(nowy); // + prod. do listy
    zapisz(); 
    pokaz(); 
    formularz.reset(); 
};
function usun(kod: string) { // usuwam produkt po kodzie
    produkty = produkty.filter(function (p) { return p.ean != kod; }); // zostawiam reszte
    zapisz(); 
    pokaz();
}
szukaj.oninput = pokaz; // jak tylko cos wpisze w wyszukiwarke - program od razu pokaże pasujace produkty
pokaz(); 
