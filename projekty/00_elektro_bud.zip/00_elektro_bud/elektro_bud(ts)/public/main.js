"use strict";
let produkty = [
    { ean: "9876543219", nazwa: "Kabel", kategoria: "Kable", sektor: "K", regal: "7", polka: "24", ilosc: 29 },
    { ean: "1234567891", nazwa: "Żarowka", kategoria: "Oświetlenie", sektor: "O", regal: "9", polka: "12", ilosc: 54 },
    { ean: "5748383874", nazwa: "Led", kategoria: "Oświetlenie", sektor: "O", regal: "10", polka: "11", ilosc: 25 }
];
const formularz = document.getElementById("formularz"); // lapiemy pola ze strony
const ean = document.getElementById("ean"); //html... pole do wpisania
const nazwa = document.getElementById("nazwa");
const kategoria = document.getElementById("kategoria");
const sektor = document.getElementById("sektor");
const regal = document.getElementById("regal");
const polka = document.getElementById("polka");
const ilosc = document.getElementById("ilosc");
const szukaj = document.getElementById("szukaj");
const lista = document.getElementById("lista");
let zapis = localStorage.getItem("produkty"); // Sprawdzamy zapisane produkty
if (zapis != null) { // czy istniwje zapis
    produkty = JSON.parse(zapis); // JSON.parse(zapis)- tekst -> dane
}
function zapisz() {
    localStorage.setItem("produkty", JSON.stringify(produkty)); // zamienism produkty na tekst i zapisuje
}
function pokaz() {
    lista.innerHTML = "";
    let tekst = szukaj.value.toLowerCase(); //pbieram tekst ze strony i zamieniam male litery na male
    for (let p of produkty) { // Lecimy po produktach
        if (p.nazwa.toLowerCase().includes(tekst) || p.ean.includes(tekst)) { // czy zawiera wpisany tekst 
            let wiersz = document.createElement("tr"); // nowy wiersz
            wiersz.innerHTML =
                "<td>" + p.ean + "</td>" +
                    "<td>" + p.nazwa + "</td>" +
                    "<td>" + p.kategoria + "</td>" +
                    "<td>" + p.sektor + "</td>" +
                    "<td>" + p.regal + "</td>" +
                    "<td>" + p.polka + "</td>" +
                    "<td>" + p.ilosc + "</td>"; // dane do tabeli
            let komorka = document.createElement("td"); // miejsce na guzik
            let guzik = document.createElement("button");
            guzik.textContent = "Usuń";
            guzik.onclick = function () { usun(p.ean); }; // Klik i produkt znika
            komorka.appendChild(guzik); // wkładamy guzik do komórki
            wiersz.appendChild(komorka); // dodajemy komórke do wiersa
            lista.appendChild(wiersz); // pokazujemy wiersz na stronie
        }
    }
}
formularz.onsubmit = function (event) {
    event.preventDefault(); //blok domyslnego dzialania i odswiezenia strony
    let nowy = {
        ean: ean.value,
        nazwa: nazwa.value,
        kategoria: kategoria.value,
        sektor: sektor.value,
        regal: regal.value,
        polka: polka.value,
        ilosc: Number(ilosc.value) //dane z formularza
    };
    produkty.push(nowy); // + prod. do listy
    zapisz();
    pokaz();
    formularz.reset();
};
function usun(kod) {
    produkty = produkty.filter(function (p) { return p.ean != kod; }); // zostawiam reszte
    zapisz();
    pokaz();
}
szukaj.oninput = pokaz; // jak tylko cos wpisze w wyszukiwarke - program od razu pokaże pasujace produkty
pokaz();
